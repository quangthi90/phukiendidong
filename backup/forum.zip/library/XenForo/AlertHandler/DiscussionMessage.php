<?php

abstract class XenForo_AlertHandler_DiscussionMessage extends XenForo_AlertHandler_Abstract
{
}