<?php

$config['db']['host'] = 'localhost';
$config['db']['port'] = '3306';
$config['db']['username'] = 'root';
$config['db']['password'] = '';
$config['db']['dbname'] = 'forum';


$config['superAdmins'] = '1';